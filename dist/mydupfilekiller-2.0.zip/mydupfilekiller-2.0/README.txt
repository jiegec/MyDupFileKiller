My Duplicate File Killer
------------------------

  My first library to find duplicate files. You can invoke the find_and_delete method to find the duplicate files in the paths.

Installation
------------------------

  Just like other ones, just type:

    pip install mydupfilekiller

  And that's all.