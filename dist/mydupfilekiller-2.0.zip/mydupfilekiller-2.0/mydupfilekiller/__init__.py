__author__ = "Wiadufa Chen <wiadufachen@gmail.com>"
from mydupfilekiller.core import *
from mydupfilekiller.gui import *
from mydupfilekiller.console import *
