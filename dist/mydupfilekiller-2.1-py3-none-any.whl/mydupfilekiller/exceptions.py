class SkipAllException(Exception):

    """
    Dummy exception class for skip_all in gui.
    """
    pass
