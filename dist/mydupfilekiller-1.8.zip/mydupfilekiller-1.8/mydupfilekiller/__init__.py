__all__ = ["mydupfilekiller"]
