class SkipAllException(BaseException):
    pass
