__author__ = "Wiadufa Chen <wiadufachen@gmail.com>"
__version__ = "2.1"
from mydupfilekiller.core import *


